package com.example.novustec;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;
import android.webkit.CookieManager;



public class MainActivity extends AppCompatActivity {

    public WebView webView;
    private long backPressedTime;


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = (WebView)findViewById(R.id.webView);

        //Initialize ConnetivityManager
        ConnectivityManager connectivityManager = (ConnectivityManager)
                getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        //Get active network info
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        //check network status
        if(networkInfo == null || !networkInfo.isConnected() || !networkInfo.isAvailable()) {
            Dialog dialog = new Dialog(this);

            //set content view
            dialog.setContentView(R.layout.alert_dialog);

            //set outside touch
            dialog.setCanceledOnTouchOutside(false);
            //set dialog width and height

            dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            //set transparent bacground
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            //set animation
            dialog.getWindow().getAttributes().windowAnimations =
                    android.R.style.Animation_Dialog;

            //Initialoize dialog variable
            Button bt_try_again = dialog.findViewById(R.id.bt_try_again);

            //perform onclick Listener
            bt_try_again.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //call recreate method
                    recreate();
                }
            });
            //show dialog
            dialog.show();
        }else{
            //when internet is active

            //Initialize websettings
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);

            //LoadURL
            webView.loadUrl("https://www.google.com/");
            webView.setWebViewClient(new WebViewClient());

            webSettings.setEnableSmoothTransition(true);

        }

    }

//    @Override
//    public void onBackPressed() {
//        if (webView.canGoBack()) {
//            webView.goBack();
//        } else {
////            if (backPressedTime +  2000 > System.currentTimeMillis()){
////                super.onBackPressed();
////                return;
////            }else{
////                Toast.makeText(getBaseContext(), "Use Navigation or Press back again to exit", Toast.LENGTH_SHORT).show();
////            }
////        }
////        backPressedTime = System.currentTimeMillis();
//
//            super.onBackPressed();
//        }
//
//    }


    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        }
        else {
            super.onBackPressed();
        }
    }

}